package com.jay.android.dispatcher.register.transform.callback

interface DeleteCallBack {
    fun delete(className: String, classBytes: ByteArray)
}